let search = document.querySelector(".search");
document.querySelector("#search").onclick =() =>{
    search.classList.toggle("active");
}
